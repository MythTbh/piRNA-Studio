# piRNA Studio

Analyze single-end small RNA FASTQ libraries against a FASTA assembly. The workspace connects sample quality, mapped coverage, cluster discovery, replicate-supported counts, differential expression, reference overlap and reproducible exports.

## Open the workspace

* **Explore precomputed results.** Open `web/dist/index.html` in a browser. The synthetic six-library study includes a fitted two-condition comparison. The separate Drosophila benchmark uses public sequencing data.
* **Analyze local files on macOS.** Double-click `Launch piRNA Studio.command`. Keep the terminal window open while a run is active. Python 3.11 or later is required. On other platforms, open a terminal in the extracted project and run `python3 -m server --port 8765`, then open http://127.0.0.1:8765.
* **Run the research tools in containers.** From this directory run `docker compose up --build`. Open the same address and choose the proTRAC backend. Docker Compose runs a web proxy and the Python engine, with analysis files in the named runs volume. Stop a local launcher before starting Compose on the same port.

## Try an analysis

The six gzipped FASTQs, sample CSV, genome FASTA, rRNA filter and reference BED in `engine/example/` form a deterministic synthetic study. Upload the FASTQs and CSV in Samples, choose the matching genome and references, then review the parameters and preflight findings. A single request can contain up to 128 MiB. For larger files use the CLI. The local server keeps its run database and uploads in `.pirna-data/`; set `PIRNA_DATA` before launch to choose another location. Local analysis is designed for a single trusted workstation.

The portable backend requires only Python and accepts references up to two million bases. It performs exact matching on both strands and groups nearby mapped loci using explicit thresholds. Use the proTRAC backend to run cutadapt, NGS TOOLBOX duster, best-hit sRNAmapper and proTRAC. Without PyDESeq2 the portable environment can export descriptive fold changes. A fitted test uses integer unique-read counts, with fractional abundances separately available in the count matrix.

## Install research mode on a workstation

From this directory, use a Python 3.12 environment and Perl. On macOS or Linux:

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r packaging/requirements.txt
python packaging/install_tools.py .tools
export DUSTER_PL="$PWD/.tools/TBr2_duster.pl"
export SRNAMAPPER_PL="$PWD/.tools/sRNAmapper.pl"
export PROTRAC_PL="$PWD/.tools/proTRAC_2.4.2.pl"
python -m server --port 8765
```

The installer fetches the upstream Perl scripts and verifies their SHA-256 digests. The macOS launcher detects this project’s .venv and .tools directories. For the optional FastAPI service run `uvicorn server.asgi:app --port 8765` with one worker.

## Command line and exports

```sh
python -m engine.pipeline engine/example/config.json runs/synthetic
python -m engine.pipeline benchmark/config.json runs/fly-window
```

Use a fresh output directory. Paths in the JSON config are relative to the config file. The second command uses the research environment. Results include BED and GFF3 features, per-sample counts, DE results, QC, read accounting, reference validation and a machine-readable provenance record. A local run’s Export tab produces an HTML report, an output archive or a reproduction kit containing the uploaded inputs. BED coordinates are zero-based and half-open.

To compare the fitted Wald statistics with R on the same integer matrix, install R, DESeq2 and jsonlite, then run:

```sh
Rscript packaging/crosscheck.R runs/synthetic Perturbed Control
```

The script writes crosscheck.tsv next to the run and reports threshold agreement and rank correlation. The demo uses generated replicates and known input regions for software verification. Biological interpretation belongs to the separate real-data benchmark, whose sampling limits and results are reported in the workspace.

## Implementation and scope

The offline web interface uses browser JavaScript, CSS and SVG. Both the Python standard-library HTTP service and the optional FastAPI entry point share the same local SQLite run store. New uploads run locally. The hosted demo distributes precomputed results.

piRNA Studio implements the input checks, portable mapper and exploratory caller, consensus algorithm, strand and sequence QC, fractional and unique counting, interval validation, run store, provenance, interface and reports. It wraps the following research software:

* [Cutadapt](https://cutadapt.readthedocs.io/) 5.1 for adapter trimming.
* [NGS TOOLBOX](https://sourceforge.net/projects/ngs-toolbox/) duster 2.1 for simple-repeat filtering.
* [sRNAmapper and proTRAC](https://sourceforge.net/projects/protrac/) 1.0.4 and 2.4.2 for mapping and probabilistic cluster discovery. The [Bioconda proTRAC recipe](https://bioconda.github.io/recipes/protrac/README.html) gives the CC BY-NC 2.0 license. The source archive supplies download instructions and checksums for the Perl tools.
* [PyDESeq2](https://pydeseq2.readthedocs.io/) 0.5.2 for negative-binomial differential testing, and [Snakemake](https://snakemake.readthedocs.io/) for workflow execution.

Repeat overlap accepts BED intervals. The optional genome-only prediction, piRBase annotation and SRA import extensions are outside this build.

## Reproduce the public benchmark

The benchmark report and interactive track use `benchmark/chromosome.json`. Run `python -m engine.pipeline benchmark/chromosome.json runs/fly-chr2R` from the research environment. The tested Perl version for this chromosome-scale run is 5.32.1. On the host’s system Perl 5.34.1, proTRAC 2.4.2 intermittently failed during its sliding-window scan. A fresh environment with Perl 5.32.1 completed the same run.

* The FASTQ contains the first 20,000 complete, unmodified records of ENA library [SRR1568761](https://www.ebi.ac.uk/ena/browser/view/SRR1568761), downloaded from its [FASTQ distribution](https://ftp.sra.ebi.ac.uk/vol1/fastq/SRR156/001/SRR1568761/SRR1568761.fastq.gz).
* The assembly is the 25,286,936-base [UCSC dm6 chromosome 2R](https://api.genome.ucsc.edu/getData/sequence?genome=dm6;chrom=chr2R). The 38 reference regions come from the [piRNAclusterDB Drosophila GTF](https://pirnaclusterdb.org/data/FASTA/Drosophila_melanogaster.piRNAclusters.gtf). Coordinates were converted to BED and region IDs checked against the database’s [abundance table](https://pirnaclusterdb.org/data/FASTA/Drosophila_melanogaster.piRNAclusters.rpm.tbl).
* The run retained 16,276 inserts in the length window and mapped 9,496 reads to 2R. The database profile called 12 clusters. Two met the 50% reciprocal-overlap criterion, giving 16.7% precision, 5.3% recall and 17.4% base-pair Jaccard overlap. The default proTRAC profile called zero clusters on the same reads. The comparison uses one shallow library and one chromosome. Its performance should be interpreted within those limits.

## Workflow and verification

To execute the staged workflow, run `snakemake -s engine/Snakefile --cores 2 --config analysis=engine/example/config.json out=runs/snake-demo` from the project root. The per-stage Conda environments can be enabled with `--software-deployment-method conda`. The research container selects the Snakemake orchestrator. Run `python -m unittest engine.test_engine engine.test_workflow server.test_service` for the test suite; full native-tool coverage requires the research dependencies. The suite checks positive and empty calls, multimapping, interval overlap, reproducibility, uploads, cancellation and exports.
